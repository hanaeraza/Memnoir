using System;
using System.Collections.Generic;

namespace Ink.Runtime
{
    public enum PushPopType 
    {
        Tunnel,
        Function,
        FunctionEvaluationFromGame
    }
}

